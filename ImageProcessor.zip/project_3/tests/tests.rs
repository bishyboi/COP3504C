#[test]
fn foo()
{
    assert_eq!(2+2, 4);
}

#[test]
fn why()
{
    assert_eq!(3,4);
}